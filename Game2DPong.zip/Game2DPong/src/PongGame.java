

public class PongGame {

	public static void main(String[] args) {
		
		 new PongFrame();
		 
	}
}
